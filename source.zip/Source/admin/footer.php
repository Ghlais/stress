        </div>
		<script src="../assets/js/oneui.min.js"></script>
        <script src="../assets/js/pages/base_pages_dashboard.js"></script>
		<script src="../assets/js/core/jquery.min.js"></script>
        <script src="../assets/js/core/bootstrap.min.js"></script>
        <script src="../assets/js/core/jquery.slimscroll.min.js"></script>
        <script src="../assets/js/core/jquery.scrollLock.min.js"></script>
        <script src="../assets/js/core/jquery.appear.min.js"></script>
        <script src="../assets/js/core/jquery.countTo.min.js"></script>
        <script src="../assets/js/core/jquery.placeholder.min.js"></script>
        <script src="../assets/js/core/js.cookie.min.js"></script>
        <script src="../assets/js/app.js"></script>
        <script src="../assets/js/plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="../assets/js/pages/base_tables_datatables.js"></script>
		<script src="../assets/js/pages/base_pages_dashboard.js"></script>
        <script>
            $(function () {
                App.initHelpers('slick');
            });
        </script>
	</body>
</html>