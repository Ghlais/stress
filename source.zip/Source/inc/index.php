<?php
	
	header('Location: ../../errors/404.php');
	exit;
	
?>